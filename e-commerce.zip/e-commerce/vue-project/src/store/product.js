import product from "@/product";
import axios from "axios";

export default {
  namespaced: true,
  state() {
    return {
      products: [],
      productDetail: null,
    };
  },
  getters: { },

  mutations: {
    setProductData(state, payload) {
      state.products = Array.isArray(payload) ? payload : []; // Pastikan payload adalah array
    },  
    setProductDetail(state, payload) {
      state.productDetail = payload;
    },
    setRelatedProduct(state, products) {
      state.relatedProducts = products
    },
    setNewProduct(state, payload) {
      state.products.push(payload);
    }
  },
  actions: {
    async getProductData({ commit }) {
      try {
        const { data } = await axios.get(
          "https://e-commerce-14011-default-rtdb.firebaseio.com/products.json"
        );
        const arr = [];
        for (let key in data) {
          arr.push({ id: key, ...data[key] });
        }
    
        console.log("Data fetched from Firebase:", arr); // Log data untuk verifikasi
        commit("setProductData", arr); // Pastikan ini array
      } catch (err) {
        console.error("Error fetching data:", err);
      }
    },
    
    // async getProductData({ commit }) {
    //   try {
    //     const { data } = await axios.get(
    //       "https://e-commerce-14011-default-rtdb.firebaseio.com/products.json"
    //     );
    //     const arr = [];
    //     for (let key in data) {
    //       arr.push({ id: key, ...data[key] });
    //     }

    //     console.log({ arr });
    //     commit("setProductData", arr);

    //     return arr;
    //   } catch (err) {
    //     console.log(err);
    //   }
    // },
    async getProductDetail({ commit }, payload) {
      try {
        const uid = isNaN(Number(payload))
        const { data } = await axios.get(
          `https://e-commerce-14011-default-rtdb.firebaseio.com/products/${uid ? `${payload}` : payload - 1}.json`
        );
        commit("setProductDetail", data);
        return data; // pastikan action mengembalikan data
      } catch (err) {
        console.log(err);
      }
    },
    async getRelatedProduct({ commit, state }, categoryType) {
      try {
          const { data } = await axios.get("https://e-commerce-14011-default-rtdb.firebaseio.com/products.json");
          const arr = [];
          for (let key in data) {
              if (data[key].category === categoryType && key !== state.productDetail.id) {
                  arr.push({ id: key, ...data[key] });
              }
          }
          commit("setRelatedProduct", arr);
      } catch (error) {
          console.log(error);
      }
    },
    async addNewProduct({ commit, rootState }, payload) {
      const newData = {
        ...payload,
        username: rootState.auth.userLogin.username,
        createdAt: Date.now(),
        likes: ["null"],
        userId: rootState.auth.userLogin.userId,
      };
      try {
        const { data } = await axios.post(
          `https://e-commerce-14011-default-rtdb.firebaseio.com/products.json?auth=${rootState.auth.token}`,
          newData
        );

        commit("setNewProduct", { id: data.name, ...newData });
      } catch (err) {
        console.error("Error posting to Firebase:", err);
      }
    },

    async deleteProduct({ dispatch, rootState }, payload) {
      try {
        const { data } = await axios.delete(
          `https://e-commerce-14011-default-rtdb.firebaseio.com/products/${payload}.json?auth=${rootState.auth.token}`
        );
        await dispatch("getProductData");
      } catch (err) {
        console.log(err);
      }
    },

    async updateProduct({ dispatch, rootState }, { id, newProduct }) {
      try {
        // Check if ID is valid
        if (!id) {
          console.error("ID tidak valid atau undefined");
          return;
        }
    
        // Make the PUT request with a valid ID
        const { data } = await axios.put(
          `https://e-commerce-14011-default-rtdb.firebaseio.com/products/${id}.json?auth=${rootState.auth.token}`,
          newProduct
        );
    
        // Dispatch to get updated recipe data
        await dispatch("getProductData");
      } catch (error) {
        console.log(error);
      }
    },
  // async addNewProduct({ commit }, productData) {
  //   try {
  //     // Mengirim data produk baru ke backend atau menambahkan ke state
  //     const { data } = await axios.post(
  //       "https://e-commerce-14011-default-rtdb.firebaseio.com/products.json",
  //       productData
  //     );
      
  //     // Optionally, fetch data ulang atau commit ke state
  //     commit("setProductData", data); // Atur sesuai kebutuhan
  //     return data; // Mengembalikan data jika perlu
  //   } catch (error) {
  //     console.error("Error adding new product:", error);
  //   }
  // },
  // async deleteProduct({ dispatch, rootState }, payload) {
  //   try {
  //     const { data } = await axios.delete(
  //       `https://e-commerce-14011-default-rtdb.firebaseio.com/products/${payload}.json?auth=${rootState.auth.token}`
  //     );
  //     await dispatch("getProductData");
  //   } catch (err) {
  //     console.log(err);
  //   }
  // },
  // async editProduct({ commit, rootState }, { id, newProduct }) {
  //   try {
  //     console.log("Editing Product ID:", id); // Cek ID produk sebelum request
  //     const { data } = await axios.put(
  //       `https://e-commerce-14011-default-rtdb.firebaseio.com/products/${id}.json?auth=${rootState.auth.token}`,
  //       newProduct
  //     );
  //     console.log("Updated Product Data:", data); // Cek data yang diterima dari API
  
  //     commit("updateProductInState", { id, updatedProduct: { ...newProduct, id } });
  //   } catch (error) {
  //     console.log(error);
  //   }
  // },
  
  },
};
