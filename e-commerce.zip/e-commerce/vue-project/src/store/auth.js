import axios from "axios";
import Cookies from "js-cookie";

export default {
  namespaced: true,
  state() {
    return {
      token: null,
      tokenExpirationDate: null,
      userLogin: {},
      isLogin: false,
    };
  },
  mutations: {
    setToken(state, { idToken, expiresIn }) {
      state.token = idToken;
      state.tokenExpirationDate = expiresIn;
      Cookies.set("tokenExpirationDate", expiresIn);
      Cookies.set("jwt", idToken);
    },
    setUserLogin(state, { userData, loginStatus }) {
      state.userLogin = userData;
      state.isLogin = loginStatus;
    },
    setUserLogout(state) {
      state.token = null;
      state.userLogin = {};
      state.isLogin = false;
      state.tokenExpirationDate = null;
      Cookies.remove("jwt");
      Cookies.remove("tokenExpirationDate");
      Cookies.remove("UID");
    },
    updateUserImage(state, newImage) {
      state.userLogin.imageLink = newImage;
    },
  

  },
  actions: {
    async getRegisterData({ commit, dispatch }, payload) {
      const APIkey = "AIzaSyArbrwFtgeoy6BLXMLsbcuIF2fqY7y0bGc";
      const authUrl = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=";

      try {
        const { data } = await axios.post(authUrl + APIkey, {
          email: payload.email,
          password: payload.password,
          returnSecureToken: true,
        });      
        commit("setToken", {
          idToken: data.idToken,
          expiresIn:
            new Date().getTime() + Number.parseInt(data.expiresIn) * 1000,
        });
        const newUserData = {
          userId: data.localId,
          fullname: payload.fullname,
          username: payload.username,
          email: payload.email,
          imageLink: payload.imageLink,
        };

        Cookies.set("UID", newUserData.userId);
        await dispatch("addNewUser", newUserData);
        return data;
      } catch (err) {
        console.log(err);
      }
    },
    async addNewUser({ commit, state }, payload) {
      try {
        const { data } = await axios.put(
          `https://e-commerce-14011-default-rtdb.firebaseio.com/user.json?auth=${state.token}`,
          payload
        );
        commit("setUserLogin", { userData: payload, loginStatus: true });
      } catch (err) {
        console.log(err);
      }
    },
    async getLoginData({ commit, dispatch }, payload) {
      const APIkey = "AIzaSyArbrwFtgeoy6BLXMLsbcuIF2fqY7y0bGc";
      const authUrl =
        "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=";
      try {
        const { data } = await axios.post(authUrl + APIkey, {
          email: payload.email,
          password: payload.password,
          returnSecureToken: true,
        });
        commit("setToken", {
          idToken: data.idToken,
          expiresIn:
            new Date().getTime() + Number.parseInt(data.expiresIn) * 1000,
        });
        await dispatch("getUser", data.localId);
        return data;
      } catch (err) {
        console.log(err);
      }
    },
    async getUser({ commit }, payload) {
      try {
        const { data } = await axios.get(
          `https://e-commerce-14011-default-rtdb.firebaseio.com/user.json`
        );
        for (let key in data) {
          if (data[key].userId === payload) {
            Cookies.set("UID", data[key].userId);
            commit("setUserLogin", { userData: data[key], loginStatus: true });
          }
        }
      } catch (err) {
        console.log(err);
      }
    },
    // async getUserData() {
    //   console.log("UDUD");
    // },
    async updateUserProfile({ commit, state }, payload) {
      try {
          const userId = state.userLogin.userId;
          if (!userId) {
              console.error("userId is not available");
              return;
          }

          const { data } = await axios.put(
            `https://e-commerce-14011-default-rtdb.firebaseio.com/user/${userId}.json?auth=${state.token}`,
              payload
          );

          commit("setUserLogin", { userData: { ...state.userLogin, ...payload }, loginStatus: true });

          return data;
      } catch (error) {
          console.error('Error updating user profile:', error);
          throw error;
      }
  },

    async uploadProfilePicture({ commit, state }, file) {
      const userId = Cookies.get("UID");
      if (!userId) throw new Error("User tidak ditemukan!");

      // Contoh upload gambar ke Firebase Storage (kamu perlu mengkonfigurasi Firebase Storage)
      const storageRef = firebase.storage().ref();
      const fileRef = storageRef.child(`profilePictures/${userId}/${file.name}`);

      try {
        // Upload file ke Firebase Storage
        const snapshot = await fileRef.put(file);
        const downloadURL = await snapshot.ref.getDownloadURL();

        // Perbarui link gambar di Realtime Database
        await this.updateProfile({ imageLink: downloadURL }); // Memanggil updateProfile dengan link gambar baru

        return "Profile picture uploaded successfully!";
      } catch (error) {
        console.error("Error uploading profile picture:", error);
        throw error;
      }
    },
  },
};
