const state = {
    orders: []
  };
  
  const mutations = {
    ADD_ORDER(state, order) {
      state.orders.push(order);
    }
  };
  
  const actions = {
    addOrder({ commit }, order) {
      commit("ADD_ORDER", order);
    }
  };
  
  export default {
    namespaced: true,
    state,
    mutations,
    actions,
  };
  