export default {
  namespaced: true,
  state: {
    orders: [],
    transactionHistory: JSON.parse(localStorage.getItem('transactions')) || [], // Load from localStorage initially
  },
  mutations: {
    addToHistory(state, items) {
      const date = new Date().toLocaleDateString(); // Get the current date
      const transactionsWithDate = items.map(item => ({
          ...item,
          date: date, // Add date to each transaction item
      }));
      state.transactionHistory.push(...transactionsWithDate);
      localStorage.setItem('transactions', JSON.stringify(state.transactionHistory)); // Save to localStorage
  },
  clearHistory(state) {
      state.transactionHistory = [];
      localStorage.removeItem('transactions'); // Clear from localStorage
  },
    // addToHistory(state, items) {
    //   // Add new items to the transactionHistory
    //   state.transactionHistory.push(...items);
    //   // Update localStorage with the new transactionHistory
    //   localStorage.setItem('transactions', JSON.stringify(state.transactionHistory));
    // },
    // You can add other mutations as needed
  },
  getters: {
    transactionHistory: (state) => state.transactionHistory,
  },
};



// export default {
//     namespaced: true,
//     state: {
//         orders: [],
//         transactionHistory: JSON.parse(localStorage.getItem('transactions')) || [],
//     },
//     mutations: {
//       addToHistory(state, items) {
//         state.transactionHistory.push(...items);
//       },
//       // Other mutations...
//     },
//     getters: {
//       transactionHistory: (state) => state.transactionHistory,
//     },
//   };

