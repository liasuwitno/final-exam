import { createStore } from 'vuex';

const state = {
    // Load cartItems from localStorage or initialize as an empty array
    cartItems: JSON.parse(localStorage.getItem('cartItems')) || [],
};

const mutations = {
    // Add item to cart and save to localStorage
    addToCart(state, product) {
        const existingItem = state.cartItems.find(item => item.id === product.id);
        if (existingItem) {
            existingItem.quantity += product.quantity; // Update quantity if item already exists
        } else {
            state.cartItems.push({ ...product, quantity: product.quantity });
        }
        localStorage.setItem('cartItems', JSON.stringify(state.cartItems)); // Save to localStorage
    },
    
    // Remove item from cart and update localStorage
    removeFromCart(state, productId) {
        state.cartItems = state.cartItems.filter(item => item.id !== productId);
        localStorage.setItem('cartItems', JSON.stringify(state.cartItems)); // Save to localStorage
    },

    // Increase quantity and save to localStorage
    increaseQuantity(state, productId) {
        const item = state.cartItems.find(item => item.id === productId);
        if (item) item.quantity++;
        localStorage.setItem('cartItems', JSON.stringify(state.cartItems)); // Save to localStorage
    },

    // Decrease quantity (min 1) and save to localStorage
    decreaseQuantity(state, productId) {
        const item = state.cartItems.find(item => item.id === productId);
        if (item && item.quantity > 1) item.quantity--;
        localStorage.setItem('cartItems', JSON.stringify(state.cartItems)); // Save to localStorage
    },

    // Clear cart and update localStorage
    clearCart(state) {
        state.cartItems = [];
        localStorage.setItem('cartItems', JSON.stringify(state.cartItems)); // Save empty array to localStorage
    },
};

const getters = {
    cartItems(state) {
        return state.cartItems;
    },
    listItemCount(state) {
        return state.cartItems.length;
    }
};

// Export the store module with `namespaced` enabled
export default {
    namespaced: true,
    state,
    mutations,
    getters,
};
