<template>
    <main class="mb-10 container">
        <form class="card-shadow mx-auto mt-4" style="width: 500px;" @submit.prevent="login">
        <div class="mb-3" style="padding: 2%; ">
          <router-link to="/" 
          type="button" class="btn-close" 
          aria-label="Close" style="float: right;">    
        </router-link>        
          <h4>Login to The SHEIN</h4>
            <p>Enter your details below</p>
          <!-- EMAIL -->
          <base-input
          type="email"
          identity="email"
          placeholder="Enter your email"
          label="Email"
          v-model="loginData.email"></base-input>
        </div>
        <div class="mb-3"  style="padding: 2%;">
          <!-- PASSWORD -->
          <base-input
          type="password"
          identity="password"
          placeholder="Enter your password"
          label="Password"
          v-model="loginData.password"></base-input>
        </div>
        <base-button type="submit" class="btnContinue mb-4 ms-4">Continue</base-button>
      </form>
      </main>
</template>

<script setup>
import { RouterLink, useRouter } from 'vue-router';
import BaseInput from '../ui/BaseInput.vue';
import BaseButton from '../ui/BaseButton.vue';
import { reactive } from 'vue';
import { useStore } from 'vuex';
import Cookies from 'js-cookie';

const store = useStore()
const router = useRouter()

const login = async () => {
await store.dispatch("auth/getLoginData", loginData);
router.push("/")
}

const loginData = reactive({
  email: "",
  password: "",
  isLogin: true
})
 
</script>

<style scoped>
.card-shadow {
    /* Shadow keunguan di bawah header */
    box-shadow: 0 4px 10px rgba(126, 96, 191, 0.6); /* Shadow warna ungu */
    margin-bottom: 16px; /* Tambahkan sedikit margin untuk estetika */
}

.card-shadow {
    transition: box-shadow 0.3s ease-in-out;
}

.btnContinue {
  justify-content: center;
    width: 450px;
    height: 40px;
    background-color: #433878;
    border: #433878;
    color: #E4B1F0;
    border-radius: 1px;
    align-self: center;
    text-align: center;
}
.btnContinue:hover {
    width: 450px;
    height: 40px;
    background-color: #E4B1F0 ;
    border: #E4B1F0;
    color: #433878;
    border-radius: 1px;
    align-self: center;
    text-align: center;
}
</style>