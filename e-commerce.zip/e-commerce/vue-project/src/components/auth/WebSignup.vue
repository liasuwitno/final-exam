<template>
  <main class="mb-10">
    <!-- Formulir Pendaftaran -->
    <form class="card mx-auto mt-5 card-shadow" @submit.prevent="register" style="width: 600px;">
      <div class="mb-3" style="padding: 2%;">
        <router-link to="/" type="button" class="btn-close" aria-label="Close" style="float: right;"></router-link>
        <h4>Sign Up</h4>
        <p>Enter your details below</p>
        <hr>
        <!-- FULL NAME -->
        <base-input
          type="text"
          identity="fullname"
          placeholder="Enter your fullname"
          label="Fullname"
          v-model="signupData.fullname">
        </base-input>
      </div>
      <div style="padding: 2%;">
        <!-- USERNAME -->
        <base-input 
          type="text"
          identity="username"
          placeholder="Enter your username"
          label="Username"
          v-model="signupData.username">
        </base-input>
      </div>
      <div style="padding: 2%;">
        <!-- EMAIL -->
        <base-input
          type="email"
          identity="email"
          placeholder="Enter your email"
          label="Email"
          v-model="signupData.email">
        </base-input>
      </div>
      <div style="padding: 2%;">
        <!-- PASSWORD -->
        <base-input
          type="password"
          identity="password"
          placeholder="Enter your password"
          label="Password"
          v-model="signupData.password" 
          @keyInput="passwordCheck">
        </base-input>
        <p class="text-danger mt-1 fw-medium" style="font-size: 11px;" :style="{ display: passwordStatusDisplay }">
          The password field must be at least 8 characters
        </p>
      </div>

      <div style="padding: 2%;">
        <!-- CONFIRMATION PASSWORD -->
        <base-input
          type="password"
          identity="confirmationPassword"
          placeholder="Confirm your password"
          label="Confirmation Password"
          v-model="signupData.confirmationPassword"
          @keyInput="confirmationPasswordCheck">
        </base-input>
        <p class="text-danger mt-1 fw-medium" style="font-size: 11px;" :style="{ display: confirmPasswordDoesNotMatch }">
          The password confirmation doesn't match
        </p>
        <p class="text-success mt-1 fw-medium" style="font-size: 11px;" :style="{ display: confirmPasswordMatch }">
          The password confirmation does match
        </p>
      </div>
      <div class=" text-center mt-4">
          <base-input 
          type="file" 
          identity="userImage" 
          label="Profile Photo" 
          isImage="true"
          @input="checkImage">
          <div>
            <div class="border p-1 mt-2 rounded-circle">
              <img 
              :src="signupData.imageLink" 
              class="rounded-circle" 
              width="140" height="150" 
              style="object-fit: cover;"/>
            </div>
            <div class="text-center" style="transform: translateY(-24px);">
              <i class="fa-solid fa-image"></i>
            </div>
          </div>
          </base-input>
        </div>
      
      <div class="mb-3 form-check d-flex">
        <input type="checkbox" class="form-check-input ms-1" id="exampleCheck1">
        <label class="form-check-label check" for="exampleCheck1">
          By clicking sign up, I hereby agree and consent to <span class="spann">Terms & Conditions;</span> I confirm that I have read <span class="spann">Privacy & Policy.</span>
        </label>
      </div>

      <base-button class="btnContinue">Continue</base-button>
    </form>

    <!-- Komponen Alert -->
    <AlertBerhasil :isVisible="alertVisible" />
  </main>
</template>

<script setup>
import BaseButton from '../ui/BaseButton.vue';
import BaseInput from '../ui/BaseInput.vue';
import AlertBerhasil from './AlertBerhasil.vue';
import { reactive, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';

const store = useStore();
const router = useRouter();
const alertVisible = ref(false);

const checkImage = (e) => {
  const file = e.target.files[0];
  const reader = new FileReader ();
  reader.readAsDataURL (file);

  reader.addEventListener ("load", () => {
    signupData.imageLink = reader.result;
  });
;}

const signupData = reactive({
  fullname: "",
  username: "",
  email: "",
  password: "",
  confirmationPassword: "",
  imageLink: "",
});

// Password validation display states
const passwordStatusDisplay = ref("none");
const confirmPasswordDoesNotMatch = ref("none");
const confirmPasswordMatch = ref("none");

// Functions for password validation
const passwordCheck = () => {
  passwordStatusDisplay.value = signupData.password.length < 8 ? "block" : "none";
};

const confirmationPasswordCheck = () => {
  if (signupData.confirmationPassword === "") {
    confirmPasswordDoesNotMatch.value = "none";
    confirmPasswordMatch.value = "none";
    return;
  }

  if (signupData.password !== signupData.confirmationPassword) {
    confirmPasswordDoesNotMatch.value = "block";
    confirmPasswordMatch.value = "none";
    return;
  }

  confirmPasswordDoesNotMatch.value = "none";
  confirmPasswordMatch.value = "block";
};

// Registration function
const register = async () => {
  if (signupData.password !== signupData.confirmationPassword || signupData.password.length < 8) {
    signupData.confirmationPassword = "";
    signupData.password = "";
    confirmPasswordDoesNotMatch.value = "none";
    confirmPasswordMatch.value = "none";
    return;
  }

  const result = await store.dispatch("auth/getRegisterData", signupData);
  
  if (result) {
    alertVisible.value = true; // Tampilkan alert jika registrasi berhasil
  } else {
    alert("Gagal melakukan registrasi");
  }
};
</script>

<style scoped>
.card-shadow {
    box-shadow: 0 4px 10px rgba(126, 96, 191, 0.6);
    margin-bottom: 16px;
}

.card-shadow {
    transition: box-shadow 0.3s ease-in-out;
}

.btnContinue {
    width: 550px;
    height: 30px;
    background-color: #433878;
    border: #433878;
    color: #E4B1F0;
    border-radius: 3px;
    align-self: center;
    text-align: center;
}
.btnContinue:hover {
    background-color: #E4B1F0;
    color: #433878;
}
.spann {
    color: blue;
    text-decoration: underline;
}
</style>
