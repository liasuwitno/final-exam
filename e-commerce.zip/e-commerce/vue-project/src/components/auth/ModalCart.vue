<template>
    <div v-if="isVisible" class="alert-overlay">
      <div class="alert-box w-50">
        <img src="../../assets/images/cart.png" alt="Cart" class="alert-image">
        <h2>Successfully Added to Cart</h2>
        <button @click="goToHomePage">Go to Home Page</button>
      </div>
    </div>
  </template>
  
  <script setup>
  import { useRouter } from 'vue-router';
  import { defineProps } from 'vue';
  
  const props = defineProps({
    isVisible: Boolean,
  });
  
  const router = useRouter();
  
  function goToHomePage() {
    router.push('/'); // Ganti URL ini dengan halaman beranda Anda
  }
  </script>
  
  <style scoped>
  .alert-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
  }
  
  .alert-box {
    background-color: white;
    padding: 20px;
    border-radius: 10px;
    text-align: center;
    width: 300px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  }
  
  .alert-image {
    width: 80px;
    margin-bottom: 20px;
  }
  
  h2 {
    font-size: 20px;
    color: #333;
    margin-bottom: 10px;
  }
  
  p {
    font-size: 14px;
    color: #666;
    margin-bottom: 20px;
  }
  
  button {
    background-color: #66198d;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
  }
  
  button:hover {
    background-color: #66198d;
  }
  </style>
  