<template>
  <div class="col-13">
      <div class="input-group align-items-center border square-pill">
          <span class="bg-transparent border-0">
            <i class="fa-brands fa-searchengin fa-xl ms-3" style="color: #58478a;"></i>
          </span>
          <input
              type="text"
              class="form-control form-control-md border-0 rounded-pill"
              placeholder="Search for items"
              v-model="searchQuery"
              @keyup.enter="searchProduct"
          />
      </div>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue';
import { useRouter } from 'vue-router';

const searchQuery = ref(''); // Menyimpan teks pencarian
const router = useRouter();
const searchProduct = () => {
  if (searchQuery.value.trim()) {
    router.push({ name: 'product2', query: { search: searchQuery.value } });
  }
};


watch(searchQuery, (newValue) => {
  if (!newValue) {
    router.push({ name: 'product2', query: { search: '' } });
  }
});

</script>

<style scoped>
.input-group {
  width: 850px;
  margin-left: 350px;
}
</style>

