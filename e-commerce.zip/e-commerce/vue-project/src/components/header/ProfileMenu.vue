<template>
  <div class="d-flex align-items-center">
    <div class="icon">
      <i class="fa-brands fa-dropbox" @click="navigateToCart" style="cursor: pointer;">
        <span v-if="listItemCount > 0" class="cart-count">{{ listItemCount }}</span>
      </i>
    </div>
    <div class="icon">
      <i class="fa-regular fa-heart" @click="goToFavorites" style="cursor: pointer;">
        <span v-if="listFavoCount > 0" class="cart-count">{{ listFavoCount }}</span>
      </i>
    </div>
    <ul class="navbar-nav">
      <li class="nav-item dropdown">
        <a
          class="nav-link dropdown-toggle"
          href="#"
          role="button"
          data-bs-toggle="dropdown"
        >
          <img
            :src="userData.imageLink"
            width="36"
            height="36"
            class="prof rounded-circle"
            style="object-fit: cover;"
          />
        </a>
        <ul class="dropdown-menu">
          <router-link to="/user/profile-detail" class="dropdown-item">
            <i class="fa-solid fa-user"></i> Profile
          </router-link>
          <router-link to="/product-cart" class="dropdown-item">
            <i class="fa-brands fa-shopify"></i> Orders
          </router-link>
          <li><hr class="dropdown-divider" /></li>
          <li class="dropdown-item" @click="showLogoutModal = true">
            <i class="fa-brands fa-openid out"></i> <span style="color: red;">Logout</span>
          </li>
        </ul>
      </li>
    </ul>
  </div>

  <!-- Modal Konfirmasi -->
  <div v-if="showLogoutModal" class="modal-backdrop show"></div> <!-- Backdrop -->
  <div v-if="showLogoutModal" class="modal show modal-custom">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5>Confirm Logout</h5>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to logout?</p>
        </div>
        <div class="modal-footer">
          <button @click="showLogoutModal = false" class="btn btn-secondary">Cancel</button>
          <button @click="logout" class="btn btn-danger">Logout</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { RouterLink } from 'vue-router';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';
import { computed, ref } from 'vue';

const store = useStore();
const router = useRouter();

const showLogoutModal = ref(false);
const logout = () => {
  store.commit("auth/setUserLogout");
  showLogoutModal.value = false;
  router.push("/");
};

const goToFavorites = () => {
  router.push("/user/favorite-item");
};

const navigateToCart = () => {
  router.push("/product-cart")
};
const userData = computed(() => {
  return store.state.auth.userLogin;
});
console.log("userr:", userData);

const listItemCount = computed(() => store.getters["cart/listItemCount"]);

const listFavoCount = computed(() => store.getters["favorite/listFavoCount"]);
</script>

<style scoped>
.d-flex {
  align-items: center; 
}

.icon i {
  font-size: 24px;
  margin-right: 50px; 
}

.prof {
  margin-top: 0; 
}

.out {
  color: red;
}

.navbar-nav .dropdown-menu {
  position: absolute; 
  z-index: 300; 
}


.modal-custom {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 400; 
  background: rgba(0, 0, 0, 0.5); 
}

.modal-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 390; 
  background-color: rgba(0, 0, 0, 0.5); 
}

.cart-count {
  color: red;
  margin-left: 5px;
  font-size: medium;
}
</style>