<template>
    <div class="header-shadow">
        <div class="h-25">
            <navigation-bar></navigation-bar>
        </div>
    </div>
</template>

<script setup>
import NavigationBar from './NavigationBar.vue';
</script>

<style scoped>
.header-shadow {
    /* Shadow keunguan di bawah header */
    box-shadow: 0 4px 10px rgba(126, 96, 191, 0.6); /* Shadow warna ungu */
    margin-bottom: 16px; /* Tambahkan sedikit margin untuk estetika */
}

/* Tambahkan transisi untuk efek halus */
.header-shadow {
    transition: box-shadow 0.3s ease-in-out;
}
</style>