<template>
  <nav class="nav d-flex">
    <router-link to="/">
      <img
        src="../../assets/images/logohh-removebg-preview.png"
        alt="Logo"
        class="logo ms-5"
      />
    </router-link>
    <search-menu style="margin-left: -15%;"></search-menu>
   
    <div class="d-flex align-items-center ms-3">
      <!-- Render each component in the `menuComponents` array -->
      <div v-for="component in menuComponents" :key="component">
        <component :is="components[component]"></component>
      </div>

      <div class="ms-5">
        <select name="language" class="form-select navdrop">
          <option value="english" class="dropdown-item">EN</option>
          <option value="indonesia" class="dropdown-item">IDN</option>
          <option value="japan" class="dropdown-item">JPN</option>
        </select>
      </div>
    </div>
  </nav>
</template>

<script setup>
import SearchMenu from "./SearchMenu.vue";
import SignupMenu from "./SignupMenu.vue";
import LoginMenu from "./LoginMenu.vue";
import ProfileMenu from "./ProfileMenu.vue";
import { computed, ref, watch } from "vue";
import { useStore } from "vuex";

const store = useStore();

const components = {
  'signup-menu': SignupMenu,
  'login-menu': LoginMenu,
  'profile-menu': ProfileMenu
};

// Menentukan komponen yang akan ditampilkan berdasarkan token login
const menuComponents = ref([]);

const getToken = computed(() => store.state.auth.token);

const updateMenuComponents = () => {
  if (!getToken.value) {
    menuComponents.value = ["signup-menu", "login-menu"];
  } else {
    menuComponents.value = ["profile-menu"];
  }
};

// Panggil fungsi saat pertama kali komponen dirender
updateMenuComponents();

// Memantau perubahan token untuk memperbarui komponen menu
watch(getToken, updateMenuComponents);
</script>
