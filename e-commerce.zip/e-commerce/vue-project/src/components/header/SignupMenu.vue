<template>
    <router-link to="/signup" type="button" class="  btnSignup">Sign Up</router-link>
</template>

<script setup>
import { RouterLink } from 'vue-router';
</script>

<style scoped>
.btnSignup {
    text-decoration: none;
    font-size: 20px;
    text-align: center;
    align-self: baseline;
    padding-top: 10px;
}
</style>