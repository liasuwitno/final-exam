<template>
    <router-link to="/login" type="button" class="btnLogin  bold ms-3 me-1">Login</router-link>
</template>

<script setup>
import { RouterLink } from 'vue-router';
</script>

<style scoped>
.btnLogin {
    text-decoration: none;
    font-size: 20px;
    text-align: center;
    align-self: center;
    border-radius: 5px;
    border: 2px solid;
    padding-top: 8px;
}
</style>