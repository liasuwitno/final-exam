<template>
    <button class="btn rounded-pill">
        <slot></slot>
    </button>
</template>