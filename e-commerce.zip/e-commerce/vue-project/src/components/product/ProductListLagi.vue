<template>
  <div class="container mt-5">
    <!-- Jika tidak ada produk yang sesuai hasil filter dan search -->
    <div v-if="filteredProducts.length === 0" class="col-12 text-center">
      <img src="../../assets/images/product_not_found.png" alt="" style="width: 25%;">
     
    </div>

    <!-- Menampilkan produk yang sesuai dengan filter -->
    <div class="product__list-product row mb-4 justify-content-center">
      <div 
        class="col-md-2 mb-4"  
        v-for="product in filteredProducts"
        :key="product.id"
        style="padding-top: 12px; padding-bottom: 12px"
      >
        <div class="text-center">
          <router-link :to="`/detail/${product.id}`" style="text-decoration: none; color: black;">
            <img 
              :src="product.imageLink"
              class="card-img-top imgList mx-auto"
              :alt="product.name"
              style="object-fit: cover; height: 300px; width: 80%;"
            />
          </router-link>
          <div class="card-body">
            <h6 style="color: #7E60BF; margin-top: 10px;">
              {{ formatRupiah(product.price) }}
            </h6>
            <p class="card-text">{{ product.name }}</p>
            <div class="justify-content-between d-flex">
              <p>{{ product.size }}</p>
              <button @click="addToFavorite(product)" class="btn">
                <i class="far fa-heart"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { watch, computed, onMounted } from 'vue';
import { useStore } from 'vuex';
import { useRoute } from 'vue-router';

const store = useStore();
const route = useRoute();

// Mendapatkan data produk dari Vuex store
const products = computed(() => store.state.product.products || []);

// Mendapatkan query search dari route
const searchQuery = computed(() => route.query.search || '');

// Filter produk berdasarkan query pencarian
const filteredProducts = computed(() => {
  let result = products.value;

  // Filter berdasarkan nama produk
  if (searchQuery.value) {
    result = result.filter(product =>
      product.name.toLowerCase().includes(searchQuery.value.toLowerCase())
    );
  }

  // Filter berdasarkan brand (jika ada filter di query)
  const brandFilter = computed(() => route.query.brand || '');
  if (brandFilter.value) {
    result = result.filter(product => product.brand === brandFilter.value);
  }

  return result;
});

// Fungsi format harga dalam Rupiah
function formatRupiah(price) {
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(price);
}

// Menambahkan produk ke favorit
function addToFavorite(product) {
  store.commit('favorite/addToFavorite', product); // Memanggil mutasi untuk menambah produk ke favorit
}

// Mengambil data produk saat komponen dimuat
onMounted(async () => {
  await store.dispatch('product/getProductData');
});
</script>

<style scoped>
.product__list-product {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}

.card-img-top {
  width: 100%;
  height: auto;
  max-height: 300px;
  object-fit: cover;
}

.card-body {
  color: #0a0a0a;
}

.card-title {
  color: #7e60bf;
}

.card-text {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}

.btn {
  background-color: transparent;
  border: none;
}

.imgList {
  object-fit: cover;
  height: 300px;
  width: 80%;
}
</style>
