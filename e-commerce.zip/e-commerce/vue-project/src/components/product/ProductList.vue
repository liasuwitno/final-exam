<template>
  <div class="product__list-product row mb-4 productList">
    <div class="d-flex justify-content-between">
      <h3 class="text-left mb-10">Popular Items</h3>
      <p class="btn adetail">See All</p>
    </div>

    <div class="d-flex">
      <div
        class="col-md-2 text-decoration-none"
        v-for="product in products"
        style="padding-top: 12px; padding-bottom: 12px"
      > 
        <div class="me-5">
          <router-link :to="`/detail/${product.id}`" class="text-decoration-none" style="color: black;">
            <img
              :src="product.imageLink"
              class="card-img-top imgList"
              :alt="product.name"
              height="240"
              width="285"
              style="object-fit: cover; height: 300px; width: 110%"
            />
          </router-link>
          <div class="card-body">
            <h6 style="color: #7E60BF; margin-top: 10px;">{{ formatRupiah(product.price) }}</h6>
            <p class="card-text">{{ product.name }}</p>
            <div class="justify-content-between d-flex">
              <p>B/M</p>
              <button class="btn" @click="addToFavorite(product)">
              <i class="far fa-heart" ></i>
              </button>
            </div>
          </div>
        </div>
      
      </div>
      <div class="card col-2 goib">
        <div>
          <router-link to="/product2" class="text-decoration-none" >
          <h5 style="align-self: center; color: black;">See All New Products</h5>
        </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { watch } from "vue";
import { useStore } from "vuex";

const props = defineProps({
  products: {
    type: Array,
    default: () => [],
  },
});
const store = useStore();
function addToFavorite(product) {
  store.commit("favorite/addToFavorite", product); // Calls Vuex mutation to add to favorite
}

function formatRupiah(price) {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(price);
};

/**
 * Digunakan untuk memastikan bahwa data yang dikirim dari props sudah terisi dan disimpan di memori
 *
 * */
watch(() => props.products);
</script>
