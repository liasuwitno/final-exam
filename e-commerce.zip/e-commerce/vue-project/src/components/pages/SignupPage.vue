<template>
   <web-signup></web-signup> 
</template>

<script setup>
import WebSignup from '../auth/WebSignup.vue';
</script>