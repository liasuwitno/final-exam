<template>
  <div>
    <div>
      <img
        src="../../assets/images/bg-image.jpg"
        alt="Background Image"
        style="width: 100%;"
      />
      <div class="card cardbg divbg" style="width: 18rem;">
        <div class="card-body">
          <h4 class="card-title">Ready to declutter your closet?</h4>
          <router-link to="/product2" 
          class="btn btn-bg" 
          style="margin-top: 50px; margin-left: 10px; width: 200px;">
            Shop Now
          </router-link>
        </div>
      </div>
    </div>
  </div>
  <div class="container" style="margin-top: 10%;">
  <div class="productList">
    <product-list :products="productList.slice(0, 5)"></product-list>
  </div>

  <div class="row mb-5 mt-5" style="margin-left: 4%;">
    <div class="col-md-6">
      <h3 class="text-left mb-10">Shop by brand</h3>
    </div>
  </div>
  <div class="row w-100" style="margin-left: 5%;">
    <!-- Bootstrap Grid -->
    <div class="col-md-10">
      <div class="d-flex flex-wrap justify-content-left gap-1" style="width: 1200px;">
        <!-- Tambahkan btn-brand ke setiap tombol -->
        <button type="button" class="btn btn-md btn-brand" @click="filterByBrand('Mango')" >Mango</button>
        <button type="button" class="btn btn-md btn-brand" @click="filterByBrand('H&M')" >H&M</button>
        <button type="button" class="btn btn-md btn-brand" @click="filterByBrand('Uniqlo')" >Uniqlo</button>
        <button type="button" class="btn btn-md btn-brand" @click="filterByBrand('Converse')" >Converse</button>
        <button type="button" class="btn btn-md btn-brand" @click="filterByBrand('Shein')" >Shein</button>
        <button type="button" class="btn btn-md btn-brand" @click="filterByBrand('Reebok')" >Reebok</button>
        <button type="button" class="btn btn-md btn-brand" @click="filterByBrand('Celine')" >Celine</button>
        <button type="button" class="btn btn-md btn-brand" @click="filterByBrand('Chanel')" >Chanel</button>
        <button type="button" class="btn btn-md btn-brand" @click="filterByBrand('Gucci')" >Gucci</button>
        <button type="button" class="btn btn-md btn-brand" @click="filterByBrand('Polo')" >Polo</button>
        <button type="button" class="btn btn-md btn-brand" @click="filterByBrand('Louis Vuitton')" >Louis Vuitton</button>
        <button type="button" class="btn btn-md btn-brand" @click="filterByBrand('Miu Miu')" >Miu Miu</button>
        <button type="button" class="btn btn-md btn-brand" @click="filterByBrand('Sophie Martin')" >Sophie Martin</button>
      </div>

    </div>
  </div>
  <div class="productList" style="margin-left: 5%; margin-top: 5%;">
    <product-list :products="productList.slice(6, 11)"></product-list>
  </div>
</div>
</template>

<script setup>
import ProductList from "../product/ProductList.vue";
import { onMounted, ref } from "vue";
import { useStore } from "vuex";

const store = useStore();
const productListStatus = ref(false);
const productList = ref([]);

onMounted(async () => {
  try {
    await store.dispatch("product/getProductData"); // Pastikan penulisan ini benar
    productListStatus.value = true;
    productList.value = store.state.product.products;
    // console.log(store.state);
  } catch (error) {
    console.log(error);
  }
});
function filterByBrand(brand) {
  // Navigasi ke halaman display dengan query brand yang dipilih
  router.push({ name: 'displayPage', query: { brand } });
}
</script>
