<template>
    <product-list-lagi
    :products="productList" v-if="productListStatus"
    ></product-list-lagi>
</template>

<script setup>
import ProductListLagi from "../product/ProductListLagi.vue";
import { onMounted, ref } from "vue";
import { useStore } from "vuex";

const store = useStore();
const productListStatus = ref(false);
const productList = ref([]);

onMounted(async () => {
  try {
    await store.dispatch("product/getProductData"); // Pastikan penulisan ini benar
    productListStatus.value = true;
    productList.value = store.state.product.products;
    // console.log(store.state);
  } catch (error) {
    console.log(error);
  }
});
</script>