<template>
    <div class="container-md  my-5 py-5">
        <product-form></product-form>
    </div>
</template>

<script setup>
import ProductForm from '../productForm/ProductForm.vue';
</script>