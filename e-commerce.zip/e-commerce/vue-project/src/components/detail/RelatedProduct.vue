<template>   
    <h2 style="width: 500px; margin-top: 50%;">Related Products</h2> 
    <div class="container d-flex" style="width: max-content;">
      <div
        style="margin-right: 50px;"
        class="col-12 col-lg-2 col-sm-2 position-relative mt-3"
        v-for="product in relatedProducts" 
        :key="product.id"
      >
        <router-link :to="`/product/${product.id}`" class="list-item text-decoration-none">
          <div class="product-card">
            <img :src="product.imageLink" :alt="product.name" class="product-image">
            <h6 style="color: #433878; margin-top: 10px;">{{ formatRupiah(product.price) }}</h6>
            <p class="small" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: black;">
              {{ product.name }}
            </p> 
            <div class=" justify-content-between text-dark">
                <p>B/M</p>
                <span><i class="fa-regular fa-heart"></i>12</span>
            </div>
          </div>
        </router-link>
       
      </div>
    </div>
  </template>
  
  <script setup>
  import { computed, onMounted } from 'vue';
  import { useStore } from 'vuex';
  
  const store = useStore();
  
  // Mengambil produk terkait dari state Vuex
  const relatedProducts = computed(() => {
    return store.state.product.relatedProducts;
  });
  
  // Memformat harga dalam format Rupiah
  function formatRupiah(price) {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(price);
  }
  
  // Mendapatkan data produk terkait saat komponen dimuat
  onMounted(async () => {
    const categoryType = store.state.product.productDetail.category; // Pastikan productDetail sudah berisi data yang diambil
    await store.dispatch('product/getRelatedProduct', categoryType);
  });
  </script>
  
  <style scoped>
  .product-card {
    display: inline-flex;
    flex-direction: column;
    align-items: center;
    width: auto; /* Biarkan lebar mengikuti gambar */
    text-align: center;
    box-shadow: 0 4px 8px rgba(128, 0, 128, 0.2); /* Shadow ungu */
    border-radius: 10px;
    padding: 10px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }
  
  .product-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 16px rgba(128, 0, 128, 0.3); /* Shadow lebih kuat saat hover */
  }
  
  .product-image {
    width: 100%;
    height: auto;
    max-height: 250px; /* Menjaga gambar tetap proporsional */
    object-fit: cover;
  }
  
  .recipe__list-recipe {
    display: flex;
    flex-wrap: wrap;
  }
  
  .container {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
  }
  </style>
  