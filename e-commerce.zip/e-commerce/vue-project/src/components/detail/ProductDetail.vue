<template>
    <div class="container text-center" style="width: max-content;" v-if="productDetail">
            <div class="">
                <div class="d-flex">
                    <div>
                        <div class="img-preview-screen">
                            <div class="img-preview-1">
                                <img :src="productDetail.imageLink" 
                                style="width: 80%; float: left; border: 1px, solid, purple; border-radius: 10px;" 
                                :alt="productDetail.name"></div>
                        </div>
                    </div>
                  <div class="col-4">
                    <div class="card card-detail" style="text-align: left; width: 150%;">
                        <div class="card-body">
                          <h2 class="card-title">{{ formatRupiah(productDetail.price) }}</h2>
                          <h6 class="card-subtitle mb-2 text-body">{{ productDetail.name }}</h6>
                          <p class="card-subtitle mb-2 text-body">
                            <span>8 / M</span>
                            <span class="mx-2">•</span>
                            <span>Very Good</span>
                            <span class="mx-2">•</span>
                            <span>Denpasar</span>
                          </p>
                          <hr>
                          <p class="card-text">{{ productDetail.description }}</p>
                          <h6 class="card-text">Size XL but fits more like M looser fit has a few minor marks (Pictured)</h6>
                          <div class="container">
                            <div class="row">
                                <div class="col-6">
                                    <p><strong>Category</strong></p>
                                    <p><strong>Size</strong></p>
                                    <p><strong>Condition</strong></p>
                                    <p><strong>Color</strong></p>
                                    <p><strong>Uploaded</strong></p>
                                    <p><strong>Shipping</strong></p>
                                </div>
                                <div class="col-6">
                                    <p>{{ productDetail.category }}</p>
                                    <p>{{ productDetail.size }}</p>
                                    <p>Very Good</p>
                                    <p>{{ productDetail.color }}</p>
                                    <p>5 hours ago</p>
                                    <p>{{ formatRupiah(productDetail.shipping) }}</p>
                                </div>
                            </div>
                        </div>
                        <hr>                    
    
                        <div class="d-grid gap-2">
                            <button class="btnSignup" type="button"  style="width: 100%" @click="handleBuyNow">Buy Now</button>
                            <button class="btnLogin" type="button"  style="width: 100%" @click="handleAddToCart">Add to Cart</button>
                        </div>
                        </div>
                        <i class="fa-regular fa-heart position-absolute top-0 end-0 m-3"></i>
                        <div class="card mt-3 p-3" style="text-align: left; width: 520px;">
                        <div class="d-flex">
                        <img
                            src="/src/assets/images/minju1.jpg"
                            alt="Seller Profile"
                            class="rounded-circle me-3"
                            style="width: 50px; height: 50px;"
                        />
                        <div>
                            <h6 class="mb-0">Emma Wong</h6>
                            <div class="text-primary">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <span class="text-muted ms-2">(1101)</span>
                            </div>
                        </div>
                        </div>
                      </div>
                      </div>
                  </div>
                </div>
            </div>
            </div>
            
</template>

<script setup>
import { onMounted, computed } from "vue";
import { useRoute, useRouter } from "vue-router";
import { useStore } from "vuex";

const store = useStore();
const route = useRoute();
const router = useRouter();

function formatRupiah(price) {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(price);
}

// Menggunakan computed untuk reaktivitas langsung dari Vuex state
const productDetail = computed(() => store.state.product.productDetail);

onMounted(async () => {
    await store.dispatch("product/getProductDetail", route.params.id);
});

const isLoggedIn = computed(() => store.state.auth.isLogin)
function handleBuyNow() {
  if (isLoggedIn.value) {
    // Tambahkan item ke cart
    const productToAdd = {
      id: productDetail.value.id,
      name: productDetail.value.name,
      price: productDetail.value.price,
      imageLink: productDetail.value.imageLink,
      size: productDetail.value.size,
      color: productDetail.value.color,
      quantity: 1,
    };
    store.commit('cart/addToCart', productToAdd);

    // Redirect ke halaman checkout
    router.push("/confirm-order"); // Ganti sesuai dengan path yang benar untuk checkout
  } else {
    router.push("/signup");
  }
}

function handleAddToCart() {
  if (isLoggedIn.value) {
    // Mengambil data produk yang akan ditambahkan ke keranjang
    const productToAdd = {
      id: productDetail.value.id,
      name: productDetail.value.name,
      price: productDetail.value.price,
      imageLink: productDetail.value.imageLink,
      quantity: 1 // atau sesuai kebutuhan Anda
    };

    // Simpan ke dalam Vuex store atau localStorage (sesuai implementasi Anda)
    store.commit('cart/addToCart', productToAdd);

    // Arahkan ke halaman order
    router.push("/product-cart");
  } else {
    // Jika belum login, arahkan ke halaman signup9
    router.push("/signup");
  }
}
</script>