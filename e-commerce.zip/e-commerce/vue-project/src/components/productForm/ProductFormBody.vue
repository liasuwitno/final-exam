<template>
    <li class="list-group-item">
      <form @submit.prevent="addNewProduct">
        <!-- General Information Start -->
        <div>
          <p class="my-3 fs-5 fw-semibold">General Information</p>
          <div>
            <!-- IMAGE START -->
            <div class="mb-3">
              <base-input
                type="file"
                identity="productImage"
                label="Photo Product"
                @input="checkImage"
              >
              </base-input>
              <div>
                <img
                  :src="productData.imageLink"
                  :alt="productData.name"
                  class="image"
                />
              </div>
            </div>
            <!-- IMAGE END -->
  
            <!-- PRODUCT NAME START -->
            <div class="mb-3">
              <base-input
                type="text"
                identity="productName"
                placeholder="Give your product a name"
                v-model="productData.name"
                label="Photo Product"
              >
              </base-input>
            </div>
            <!-- PRODUCT NAME END -->
  
            <!-- PRODUCT DESC START -->
            <div class="mb-3">
              <base-text-area
                type="productDescription"
                label="Description"
                placeholder="Share story behind product and
                  what is make ip special"
                v-model="productData.description"
              >
              </base-text-area>
            </div>
            <!-- PRODUCT DESC END -->
  
            <!-- PRODUCT CATEGORY START -->
            <div class="mb-3">
              <base-select
                :data="['Top', 'Skirt', 'Shoes', 'Pants']"
                v-model="productData.category"
              >
              </base-select>
            </div>
            <!-- PRODUCT CATEGORY END -->
  
            <!-- COLOR START -->
            <div class="mb-3">
                <base-input
                type="text"
                identity="productColor"
                placeholder="Give your product a color"
                v-model="productData.color"
                label="Color Product"
                >
                </base-input>
            </div>
            <!-- COLOR END -->
            
            <!-- SIZE START -->
            <div class="mb-3">
                <base-select
                    :data="['S', 'M', 'L', 'XL', 'XXL', 'XXXL']"
                    v-model="productData.size"
                >
                </base-select>
            </div>
            <!-- SIZE END -->

            <!-- BRAND START -->
            <div class="mb-3">
                <base-input
                type="text"
                identity="productBrand"
                placeholder="Give your product a brand"
                v-model="productData.brand"
                label="Brand"
                >
                </base-input>
            </div>
            <!-- BRAND END -->

            <!-- PRICE START -->
            <div class="mb-3">
                <base-input
                type="text"
                identity="productPrice"
                placeholder="Give your product a price"
                v-model="productData.price"
                label="Price"
                >
                </base-input>
            </div>
            <!-- PRICE END -->

            <!-- SHIPPING START -->
            <div class="mb-3">
                <base-input
                type="text"
                identity="productShipping"
                placeholder="Give your product a shipping"
                v-model="productData.shipping"
                label="Shipping"
                >
                </base-input>
            </div>
            <!-- SHIPPING END -->
        </div>
    </div>
         <!-- General Information End -->
  
        <!-- Form Button Start -->
        <div class="border-top py-3 d-flex my-4 justify-content-end">
          <!-- Cancel Button Start -->
           <router-link to="/user/user-product">
          <base-button class="cancel-btn px-3 py-2 ms-1 btn-warning" type="button" 
            >Cancel</base-button>
           </router-link>
          
          <!-- Cancel Button End -->
  
          <!-- Submit Button Start -->
          <base-button
            class="submit-product-btn px-3 py-2 ms-1 btn-success"
            type="button"
            @click="addNewProduct"
            >Submit</base-button
          >
          <!-- Submit Button End -->
        </div>
        <!-- Form Button End -->
      </form>
    </li>
  </template>
  
  <script setup>
  import BaseInput from "../ui/BaseInput.vue";
  import BaseTextArea from "../ui/BaseTextArea.vue";
  import BaseSelect from "../ui/BaseSelect.vue";
  import BaseButton from "../ui/BaseButton.vue";
  import { reactive, ref } from "vue";
  import { useStore } from "vuex";
  import { useRouter, useRoute } from "vue-router";
  import { onMounted } from "vue";
  import { RouterLink } from "vue-router";
  
  const productData = ref({
    imageLink: "",
    name: "",
    description: "",
    category: "",
    color: "",
    size: "",
    brand: "",
    price: "",
    shipping: "",
  });
  
  const checkImage = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
  
    reader.addEventListener("load", () => {
      productData.value.imageLink = reader.result;
    });
  };
  
  const store = useStore();
  const router = useRouter();
  const route = useRoute();
  
  const props = defineProps({
    isEdit: { type: Boolean, require: false },
  });

  const addNewProduct = async () => {
    console.log("Product data:", productData.value);
    const plainProductData = JSON.parse(JSON.stringify(productData.value));
  
    if (props.isEdit) {
      // Pastikan route.params.id ada
      if (route.params.id) {
        await store.dispatch("product/updateProduct", {
          id: route.params.id,
          newProduct: plainProductData, // Menggunakan plainProductData
        });
      } else {
        console.error("ID tidak ditemukan di parameter route");
      }
    } else {
      await store.dispatch("product/addNewProduct", plainProductData);
    }
  
    router.push("/user/user-product");
  };
  
  onMounted(() => {
    if (props.isEdit) {
      productData.value = store.state.product.productDetail;
    } else {
      console.log("test");
    }
  });
  </script>