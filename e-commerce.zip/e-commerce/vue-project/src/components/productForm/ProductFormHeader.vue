<template>
    <li class="list-group-item">
      <div class="d-flex align-items-center px-3">
        <router-link to="/user/user-recipe"><i class="fa-regular fa-hand-point-down fa-2xl" style="color: #B197FC;"></i>
        </router-link>
        <div class="ms-4">
          <p class="my-0 fs-4 fw-semibold">Add Product</p>
          <p class="my-0">
            Uploading your personal here! Add yours to your favorites, share
            with friends, family, or The SHEIN's community.
          </p>
        </div>
      </div>
    </li>
  </template>