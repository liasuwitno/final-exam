<template>
    <footer class="footer bgfooter text-white mt-5">
        <div class="container">
          <div class="row">
            <!-- Column 1 -->
            <div class="col-md-3">
              <h5>Vintage</h5>
              <ul class="list-unstyled">
                <li>About Us</li>
                <li>Sustainability</li>
                <li>Blog</li>
                <li>Advertising</li>
              </ul>
            </div>
      
            <!-- Column 2 -->
            <div class="col-md-3 a">
              <h5>Discover</h5>
              <ul class="list-unstyled">
                <li>How it works</li>
                <li>Help Center</li>
                <li>Info Board</li>
                <li>Mobile Apps</li>
              </ul>
            </div>
      
            <!-- Column 3 -->
            <div class="col-md-3">
              <h5>Help</h5>
              <ul class="list-unstyled">
                <li>Help Center</li>
                <li>Buying</li>
                <li>Trus and Safety</li>
              </ul>
            </div>
      
            <!-- Column 4 -->
            <div class="col-md-3">
              <h5>Community</h5>
              <ul class="list-unstyled">
                <li>Forum</li>
              </ul>
            </div>
          </div>
          <hr>
            <nav class="navbar navbar-expand-lg">
                <div class="container-fluid">
                    <div class="ms-5">
                        <i class="fa-brands fa-whatsapp me-3"></i>
                        <i class="fa-brands fa-instagram me-3"></i>
                        <i class="fa-brands fa-linkedin me-3"></i>
                    </div>
                    <p class="me-5">&copy;Vintage, 2024</p>
                </div>
              </nav>
    </div>
      </footer>
</template>