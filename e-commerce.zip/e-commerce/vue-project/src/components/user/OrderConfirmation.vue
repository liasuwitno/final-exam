<template>
  <div class="order-confirmation">
    <h1>Order Confirmation</h1>

    <div class="order-details">
      <div class="order-items">
        <h2>Order</h2>
        <ul type="none" class="card">
          <li v-for="(item, index) in cartItems" :key="index">
            <div class="item-details mt-5">
              <img :src="item.imageLink" alt="Product Image" class="product-image" />
              <div class="product-info">
                <p>{{ item.name }}</p>
                <p>{{ formatRupiah(item.price) }}</p>
                <p>Quantity: {{ item.quantity }}</p>
                <hr>
              </div>
            </div>
          </li>
        </ul>
      </div>

      <div class="summary card">
        <h2>Order Summary</h2>
        <p>Order: {{ formatRupiah(calculateTotal()) }}</p>
        <p>Shipping: {{ formatRupiah(shippingFee) }}</p>
        <p><strong>Total to Pay: {{ formatRupiah(totalToPay) }}</strong></p>
        <button @click="processOrder" class="btn">Order Now</button>
      </div>
    </div>

    <div class="address-details">
      <h2>Address</h2>
      <p>{{ orderDetails.address }}</p>
    </div>

    <div class="delivery-details">
      <h2>Delivery Details</h2>
      <p>{{ orderDetails.deliveryMethod }}</p>
    </div>

    <div class="payment-details">
      <h2>Payment Method</h2>
      <p>{{ orderDetails.paymentMethod }}</p>
    </div>

    <!-- Modal Virtual Account -->
    <div v-if="showModal" class="modal-backdrop">
      <div class="modal-content">
        <h5>Pembayaran via Virtual Account</h5>
        <p>Nomor Virtual Account: 1234567890</p>
        <button @click="confirmOrder" class="btn btn-success mt-3">OK</button>
      </div>
    </div>

    <!-- Order Confirmation Modal -->
    <div v-if="showOrderConfirmation" class="modal-backdrop">
      <div class="modal-content">
        <p>Order <strong>{{ orderDetails.orderID }}</strong> placed successfully</p>
        <p>Thank you for shopping with us! You can check your order status in Transaction History.</p>
        <button @click="continueShopping" class="btn">Continue Shopping</button>
        <router-link to="/user/transaction-history" class="btn">Go to History Transaction</router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { useStore } from 'vuex';
import { useRouter } from 'vue-router';

const store = useStore();
const router = useRouter();
const showModal = ref(false);
const showOrderConfirmation = ref(false);
const cartItems = computed(() => store.getters['cart/cartItems']);
const shippingFee = 10000;
const totalToPay = computed(() => calculateTotal() + shippingFee);

const orderDetails = computed(() => ({
  orderID: 'ORD-89213-823',
  address: 'Jl. Raya 1, Jakarta Selatan, Indonesia, 12610',
  deliveryMethod: 'Fedex Express Shipping (3-5 working days)',
  paymentMethod: 'VISA 1234 **** **** 5678'
}));

// Format price
function formatRupiah(price) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
  }).format(price);
}

// Calculate total order amount
function calculateTotal() {
  return cartItems.value.reduce((total, item) => total + item.price * item.quantity, 0);
}

// Process order and show virtual account modal
function processOrder() {
  showModal.value = true;
}

// Confirm order, save to history, and show confirmation modal
function confirmOrder() {
  store.commit('transaction/addToHistory', cartItems.value);
  store.commit('cart/clearCart');
  showModal.value = false;
  showOrderConfirmation.value = true;
}

// Redirect to continue shopping
function continueShopping() {
  router.push('/product2');
}
</script>

<style scoped>
.order-confirmation {
  max-width: 900px;
  margin: 0 auto;
  padding: 20px;
}
.order-details {
  display: flex;
  justify-content: space-between;
  gap: 20px;
}
.order-items {
  width: 48%;
  padding: 10px;
} .summary {
  width: 48%;
  padding: 10px;
  background: linear-gradient( #FFE1FF,#433878);
}
.item-details {
  display: flex;
  gap: 15px;
  margin-bottom: 10px;
}
.product-image {
  width: 100px;
}
.address-details, .delivery-details, .payment-details {
  margin-top: 20px;
}
.modal-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}
.modal-content {
  background: white;
  padding: 20px;
  border-radius: 8px;
  text-align: center;
  max-width: 400px;
  width: 100%;
}
.btn {
  display: inline-block;
  margin: 10px;
  padding: 10px 20px;
  background: #433878;
  color: #FFE1FF;
  border: none;
  cursor: pointer;
  border-radius: 4px;
}
</style>
