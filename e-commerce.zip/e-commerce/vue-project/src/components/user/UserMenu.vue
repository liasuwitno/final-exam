<template>
    <div class="col-lg-3 mb-4" style="margin-left: 2%; width: 300px;">
      <h3>Settings</h3>
      <ul type="none">
        <li class="user-menu" @click="menuClicked('profile-detail')">
          Profile Details
        </li>
        <li class="user-menu" @click="menuClicked('change-password')">
          Change Password
        </li>
        <li class="user-menu" @click="menuClicked('transaction-history')">
         Transaction History
        </li>
        <li class="user-menu" @click="menuClicked('user-product')">
          My Products
        </li>
      </ul>
    </div>
  </template>
  
  
  <style scoped>
.user-menu {
  padding: 10px 15px;
  border-radius: 5px;
  transition: background-color 0.3s, color 0.3s;
}

.user-menu:hover {
  cursor: pointer;
  background-color: #f0f0f0; /* Light background on hover */
  color: #4c4ddc; /* Change text color on hover */
}

.active-color {
  color: #4c4ddc;
}

.inactive-color {
  color: #404040;
}
</style>


<script setup>
import { computed } from "vue";
import { useStore} from "vuex";

const store = useStore() 
const userData = computed (() => {
    return store.state.auth.userLogin
})

const emit = defineEmits(['changeComponent'])

const menuClicked = option => {
    emit ("changeComponent", option)
}
</script>
