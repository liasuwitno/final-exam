<template>
  <div class="favorite-items ms-5">
    <h2>Your Favorite Items</h2>

    <!-- Tampilan jika tidak ada item favorit -->
    <div v-if="favoriteItems.length === 0" class="no-items card container w-25">
      <img src="../../assets/images/favo.png" alt="Favorite Items" class="w-50 mt-3 mx-auto d-block" />
      <p class="text-center mt-3">No favorite items yet</p>
      <router-link to="/product2" class="btn btn-info w-50 mx-auto d-block my-3">Shop now</router-link>
    </div>

    <!-- Tampilan jika ada item favorit -->
    <div v-else>
      
      <div class="items-list ms-5 w-75 d-flex flex-wrap gap-4">
        <div v-for="item in favoriteItems" :key="item.id" class="item-card card p-3">
          <router-link :to="`/detail/${item.id}`" class="text-decoration-none" style="color: black;">
            <img :src="item.imageLink" :alt="item.name" class="item-image mx-auto"/>
            <h4 class="item-name text-center mt-2">{{ item.name }}</h4>
            <p class="text-center text-muted">{{ formatRupiah(item.price) }}</p>
          </router-link>
        </div>
      </div>
      <button @click="clearFavorites" class="btn btn-danger mt-5">Clear Favorites</button>
    </div>
  </div>
</template>

<script>
import { computed, onMounted, watch } from 'vue';
import { useStore } from 'vuex';

const formatRupiah = (value) => {
  if (!value) return '';
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(value);
};

export default {
  setup() {
    const store = useStore();
    const favoriteItems = computed(() => store.getters['favorite/favoriteItems'] || []);

    // Memanggil mutasi untuk clear semua favorite
    const clearFavorites = () => {
      store.commit('favorite/clearFavorites');
    };

    onMounted(() => {
      const savedFavorites = localStorage.getItem('favoriteItems');
      if (savedFavorites) {
        store.commit('favorite/setFavoriteItems', JSON.parse(savedFavorites));
      }
    });

    watch(favoriteItems, (newFavorites) => {
      localStorage.setItem('favoriteItems', JSON.stringify(newFavorites));
    }, { deep: true });

    return { favoriteItems, formatRupiah, clearFavorites };
  }
};
</script>

<style scoped>
.favorite-items {
  margin: 0 auto;
  width: 100%;
}

.no-items {
  text-align: center;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(128, 0, 128, 0.2);
}

.items-list {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-start;
  gap: 20px;
}

.item-card {
  width: 200px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(128, 0, 128, 0.2);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.item-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 16px rgba(128, 0, 128, 0.3);
}

.item-image {
  width: 100%;
  height: auto;
  max-height: 150px;
  object-fit: cover;
  border-radius: 8px;
}

.item-name {
  font-weight: bold;
  color: #4a4a4a;
}

p {
  margin: 0;
}
</style>
