<template>
    <ul class="list-group">
      <li class="list-group-item">
        <div
          class="d-flex flex-sm-row flex-column justify-content-between align-items-sm-center"
        >
          <div class="mb-3 mb-sm-0">
            <p class="my-0 fs-4 fw-semibold">My Product</p>
            <p class="my-0 text-secondary">Add your products here</p>
          </div>
          <router-link to="/new-product">
            <base-button class="btn add-btn px-3 py-2 rounded-pill btn-primary">
            <i class="fa-regular fa-square-plus"></i> Add Product
            </base-button>
          </router-link>
        </div>
      </li>
      <li class="list-group-item">
        <p class="mt-2 mb-4 fs-5 fw-semibold">Products</p>
        <div class="row">
          <user-product-card
            v-for="product in products"
            :key="product.id"
            :product="product"
            :buttonName="['Delete', 'Edit']"
            @btnRemove="deleteProduct(product.id)"
            @btnEdit="updateProduct(product.id)"
          >
          <p>{{ new Date(product.createdAt).toDateString() }}</p>
          </user-product-card>
        </div>
      </li>
    </ul>
  </template>
  
  <script setup>
  import BaseButton from "../ui/BaseButton.vue";
  import { RouterLink, useRoute } from "vue-router";
  import { computed, onMounted, ref } from "vue";
  import { useStore } from "vuex";
  import UserProductCard from "./UserProductCard.vue";
  import {useRouter} from "vue-router";
  
  
  const router = useRouter()
  const store = useStore();
  
  const productListStatus = ref(false);
  const products = ref();
  
  console.log({ products: store.state.product.product });
  
  onMounted(async () => {
    try {
      await store.dispatch("product/getProductData");
      productListStatus.value = true;
  
      const userId = store.state.auth.userLogin.userId;
      products.value = store.state.product.products.filter(
        (product) => product.userId === userId
      );
    } catch (error) {
      console.log(error);
    }
  });
  
  const product = computed(() => {
    const allProduct = store.state.product.products;
    const userId = store.state.auth.userLogin.userId;
    return allProduct.filter((product) => product.userId === userId);
  });
  
  const deleteProduct = async (id) => {
    await store.dispatch("product/deleteProduct", id);
  };
  const updateProduct = (id) => {
    router.push({name: "editProductPage", params: {id}});
  };
  </script>
  
  