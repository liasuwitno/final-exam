<template>
        <div class="col-md-8">
                  <div class="card">
                      <div class="card-body">
                          <h3>Change Password</h3>
                          <div class="form-group">
                          <hr>
                          </div>
                          <form>
                              <div class="form-group">
                                  <label for="fullName">Old Password</label>
                                  <input type="text" class="form-control" id="fullName" placeholder="Enter your old password">
                              </div>
                              <div class="form-group">
                                  <label for="username">New Password</label>
                                  <input type="text" class="form-control" id="username" placeholder="Enter your new password">
                              </div>
                              <div class="form-group">
                                  <label for="nickname">Confirmation New Password</label>
                                  <input type="text" class="form-control" id="nickname" placeholder="Confirm your new password">
                              </div>
                              <div>
                                <button type="submit" style="width: 130px; 
                                    border: 2px solid #8a2be2; /* Border purple */
                                    background-color: plum; 
                                    border-radius: 5px; /* Slightly rounded corners */
                                    padding: 8px 0; 
                                    color: white;
                                    float: right;">
                                        Update Profile
                                </button>
                             </div>
                          </form>
                      </div>
                  </div>
              </div>
</template>