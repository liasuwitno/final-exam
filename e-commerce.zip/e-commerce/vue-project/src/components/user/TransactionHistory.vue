<template>
  <div class="transaction-history card">
    <h2>Transaction History</h2>
    
    <div v-if="transactionHistory.length === 0" class="empty-orders">
      <img src="../../assets/images/no_order.png" alt="No orders icon" class="empty-icon" />
      <p>No orders yet</p>
      <p>When you buy an item, your order will appear here.</p>
      <router-link to="/product2" class="shop-now-button">Shop now</router-link>
    </div>

    <div v-else class="order-list">
      <div v-for="order in transactionHistory" :key="order.id" class="order-item">
        <img :src="order.imageLink" :alt="order.name" class="order-image" />
        <div class="order-details">
          <h3>{{ order.name }}</h3>
          <p>Price: {{ order.price }}</p>
          <p>Date: {{ order.date }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { computed } from "vue";
import { useStore } from "vuex";

export default {
  setup() {
    const store = useStore();
    const transactionHistory = computed(() => store.getters['transaction/transactionHistory'] || []);

    return {
      transactionHistory,
    };
  },
};
</script>


<style scoped>
.transaction-history {
  padding: 20px;
}

.empty-orders {
  text-align: center;
  margin-top: 50px;
}

.empty-icon {
  width: 300px;
  margin-bottom: 20px;
}

.shop-now-button {
  display: inline-block;
  margin-top: 20px;
  padding: 10px 20px;
  background-color: violet;
  color: black;
  border-radius: 4px;
  text-decoration: none;
}

.order-list {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.order-item {
  display: flex;
  align-items: center;
  gap: 20px;
  border: 1px solid #ddd;
  padding: 15px;
  border-radius: 8px;
}

.order-image {
  width: 80px;
  height: 80px;
  object-fit: cover;
}

.order-details {
  flex: 1;
}
</style>
