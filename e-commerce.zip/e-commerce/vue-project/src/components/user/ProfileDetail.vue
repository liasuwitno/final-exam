<template>
  <div class="col-md-8 prof-detail">
    <div class="card">
      <div class="card-body">
        <h3>Edit Profile</h3>
        <form @submit.prevent="updateUserProfile">
          <div class="d-flex justify-content-between mb-3">
            <div>
              <p>Photo</p>
            </div>
            <div class="profile-picture d-flex align-items-center">
              <img
                :src="previewImage || userData.imageLink"
                alt="Profile Picture"
                class="profile-img"
                style="object-fit: cover"
              />
              <input
                type="file"
                @change="onFileChange"
                accept="image/png, image/jpeg"
                ref="fileInput"/>
              <span class="text-muted mx-2">JPG, JPEG, or PNG, max 1 MB.</span>
            </div>
          </div>

          <div class="mb-3">
            <label for="fullName">Full Name</label>
            <input
              type="text"
              class="form-control"
              id="fullName"
              placeholder="Fullname"
              v-model="userData.fullname"
            />
          </div>
          <div class="mb-3">
            <label for="username">Username</label>
            <input
              type="text"
              class="form-control"
              id="username"
              placeholder="Username"
              v-model="userData.username"
            />
          </div>
          <div class="mb-3">
            <label for="email">Email</label>
            <input
              type="email"
              class="form-control"
              id="email"
              placeholder="Email"
              v-model="userData.email"
            />
          </div>
          <div class="d-flex justify-content-end">
            <button
              type="submit"
              class="btn btn-primary"
              style="width: 130px; border-radius: 5px;"
            >
              Update Profile
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue';
import { useStore } from 'vuex';

const store = useStore();
const userData = computed(() => store.state.auth.userLogin);
const userId = computed(() => userData.value.userId);
const imageLink = ref(userData.value.imageLink);
const previewImage = ref(null); 

const onFileChange = (event) => {
    const file = event.target.files[0];
    if (file && file.size <= 1048576) { 
        const reader = new FileReader();
        reader.onload = (e) => {
            imageLink.value = e.target.result;
            previewImage.value = e.target.result; 
        };
        reader.readAsDataURL(file);
    } else {
        alert("Please select a valid image file under 1 MB.");
    }
};

const updateUserProfile = async () => {
    const updatedData = {
        fullname: userData.value.fullname,
        username: userData.value.username,
        email: userData.value.email,
        imageLink: imageLink.value || userData.value.imageLink,
    };

    try {
        await store.dispatch('auth/updateUserProfile', { userId: userId.value, ...updatedData });
        console.log('Profile updated successfully!');
    } catch (error) {
        console.error('Error updating profile:', error);
    }
};
</script>

<style scoped>
.prof-detail {
  margin: 0 auto;
  width: 80%;
}
</style>
