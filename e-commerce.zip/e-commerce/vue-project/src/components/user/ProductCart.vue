product order ni halaman cart

<template>
  <div class="container mt-5">
    <div class="row">
      <div class="col-md-8">
        <h3>Keranjang Belanja</h3>
        <div v-if="cartItems.length === 0" class="py-5 text-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="70" height="70" fill="#17a2b8" class="bi bi-cart" viewBox="0 0 16 16">
            <path d="M0 1.5A.5.5 0 0 1 .5 1h1a.5.5 0 0 1 .49.598L1.89 3H14.5a.5.5 0 0 1 .49.598l-1.5 6A.5.5 0 0 1 13 10H4a.5.5 0 0 1-.49-.402L1.61 3.607 1.11 2H.5a.5.5 0 0 1-.5-.5zM3.14 4l1.25 5h8.22l1.25-5H3.14zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm9 2a2 2 0 1 1-4 0 2 2 0 0 1 4 0z"/>
          </svg>
          <p class="mt-4">Keranjang Anda masih kosong</p>
          <p>Cari item favorit Anda dan tambahkan ke keranjang sebelum checkout.</p>
          <router-link to="/" class="btn btn-info btn-lg mt-3">Cari Produk</router-link>
        </div>
        <div v-else>
          <div v-for="item in cartItems" :key="item.id" class="cart-item d-flex justify-content-between align-items-center border-bottom py-3">
            <div>
              <img
                :src="item.imageLink"
                class="card-img-top"
                :alt="item.name"
                height="180"
                width="30"
                style="object-fit: cover"
              />
              <h6>{{ item.name }} - {{ formatRupiah(item.price) }}</h6>
              <div class="quantity-controls d-flex align-items-center">
                  <button @click="decreaseQuantity(item.id)" :disabled="item.quantity <= 1" class="btn btn-outline-secondary btn-sm">-</button>
                    <span class="mx-2">x{{ item.quantity }}</span>
                  <button @click="increaseQuantity(item.id)" class="btn btn-outline-secondary btn-sm">+</button>
              </div>
            </div>
            <button @click="removeFromCart(item.id)" class="btn btn-danger btn-sm">Hapus</button> <!-- Tombol untuk menghapus item -->
          </div>
          <div class="mt-5"> 
            <h3>Other products</h3>
            <product-list
            :products="productList.slice(1, 6)"></product-list>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Ringkasan Pesanan</h5>
            <p class="card-text">{{ cartItems.length }} item</p>
            <p class="card-text text-muted">Belum termasuk biaya pengiriman</p>
            <h6 class="card-subtitle mb-3">{{ calculateTotal() }}</h6>
            <button class="btn btn-secondary btn-block" :disabled="cartItems.length === 0" @click="handleCheckout">Checkout</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import ProductList from "../product/ProductList.vue";
import { computed, onMounted, ref } from "vue";
import { useStore } from "vuex";
import { useRouter } from "vue-router";

const store = useStore();
const cartItems = computed(() => store.getters['cart/cartItems']);

const router = useRouter();

const productListStatus = ref(false);
const productList = ref([]);
const isLoggedIn = computed(() => store.state.auth.isLogin)


function handleCheckout() {
    if (cartItems.value.length > 0) {
      router.push("/confirm-order");
    }
}

onMounted(async () => {
  try {
    await store.dispatch("product/getProductData"); // Pastikan penulisan ini benar
    productListStatus.value = true;
    productList.value = store.state.product.products;
    // console.log(store.state);
  } catch (error) {
    console.log(error);
  }
});

// Fungsi untuk menghapus item dari keranjang
function removeFromCart(productId) {
    store.commit('cart/removeFromCart', productId);
}

// Fungsi untuk menambah jumlah item
function increaseQuantity(productId) {
    store.commit('cart/increaseQuantity', productId);
}

// Fungsi untuk mengurangi jumlah item
function decreaseQuantity(productId) {
    store.commit('cart/decreaseQuantity', productId);
}

// Fungsi untuk format harga
function formatRupiah(price) {
    return new Intl.NumberFormat("id-ID", {
        style: "currency",
        currency: "IDR",
    }).format(price);
}

// Fungsi untuk menghitung total harga
function calculateTotal() {
    return formatRupiah(cartItems.value.reduce((total, item) => total + (item.price * item.quantity), 0));
}

</script>

<style scoped>
.cart-item {
    padding: .75rem;
}
.quantity-controls {
    display: flex;
    align-items: center;
}
.quantity-controls button {
    margin: 0 .25rem;
}
.btn-danger {
    margin-left: .75rem;
}
.card {
    border: none;
}
.card-title {
    font-size: larger;
}
.card-subtitle {
    font-weight: bold;
}
</style>