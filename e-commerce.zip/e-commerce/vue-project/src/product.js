export default [
    {
      id: 1,
      category: "Skirt",
      color: "Brown",
      description: "Effortlessly chic with a relaxed fit.",
      name: "Miss Glow and Simple",
      price: 120000,
      imageLink: "src/assets/images/pr1.jpg",
      shipping: 60000,
      size: "S"
    },
    {
      id: 2,
      category: "Dress",
      color: "Pink",
      description: "Soft, flowy, and endlessly flattering.",
      name: "Double Booster",
      price: 115000,
      imageLink: "src/assets/images/pr2.jpg",
      shipping: 50000,
      size: "S"
    },
    {
      id: 3,
      category: "Cardigan",
      color: "Green",
      description: "Perfect for layering with a cozy touch.",
      name: "Dubai Sparks",
      price: 130000,
      imageLink: "src/assets/images/pr3.jpg",
      shipping: 70000,
      size: "S"
    },
    {
      id: 4,
      category: "Top",
      color: "White",
      description: "Clean, crisp, and easy to style.",
      name: "London Hill",
      price: 125000,
      imageLink: "src/assets/images/pr4.jpg",
      shipping: 65000,
      size: "S"
    },
    {
      id: 5,
      category: "Corset",
      color: "Red",
      description: "Bold and beautiful with a perfect fit.",
      name: "Broken Wings",
      price: 110000,
      imageLink: "src/assets/images/pr5.jpg",
      shipping: 55000,
      size: "S"
    },
    {
      id: 6,
      category: "Mini Dress",
      color: "Gray",
      description: "Sleek, modern, and effortlessly stylish.",
      name: "Moku Youbi",
      price: 135000,
      imageLink: "src/assets/images/pr6.jpg",
      shipping: 60000,
      size: "S"
    },
    {
      id: 7,
      category: "Mini Dress",
      color: "Green",
      description: "Fresh and fun, perfect for any outing.",
      name: "Clap on Okane",
      price: 145000,
      imageLink: "src/assets/images/pr7.jpg",
      shipping: 65000,
      size: "S"
    },
    {
      id: 8,
      category: "Mini Dress",
      color: "Maroon",
      description: "Elegant and bold, a statement piece.",
      name: "Subarashii Yabai",
      price: 140000,
      imageLink: "src/assets/images/pr8.jpg",
      shipping: 70000,
      size: "S"
    },
    {
      id: 9,
      category: "Dress",
      color: "Cream",
      description: "Soft tones with a dreamy silhouette.",
      name: "Pearly Bone",
      price: 105000,
      imageLink: "src/assets/images/pr9.jpg",
      shipping: 50000,
      size: "S"
    },
    {
      id: 10,
      category: "Dress",
      color: "White",
      description: "Pure elegance in every stitch.",
      name: "Cute and Pure",
      price: 130000,
      imageLink: "src/assets/images/pr10.jpg",
      shipping: 60000,
      size: "S"
    },
    {
      id: 11,
      category: "Top",
      color: "Blue",
      description: "Bright and breezy, ideal for any day.",
      name: "Blue Butterfly",
      price: 125000,
      imageLink: "src/assets/images/pr11.jpg",
      shipping: 55000,
      size: "S"
    },
    {
      id: 12,
      category: "Mini Dress",
      color: "Pink",
      description: "Fun and flirty, a pop of color for your wardrobe.",
      name: "Pink Poppy",
      price: 115000,
      imageLink: "src/assets/images/pr12.jpg",
      shipping: 50000,
      size: "S"
    },
    {
      id: 13,
      category: "T-Shirt",
      color: "Black",
      description: "Edgy, bold, and unapologetically cool.",
      name: "Y2K on Fire",
      price: 150000,
      imageLink: "src/assets/images/pr13.jpg",
      shipping: 75000,
      size: "S"
    }
];
